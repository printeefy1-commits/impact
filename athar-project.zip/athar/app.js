const $=id=>document.getElementById(id);
let state=null;
const topologyView=new Topology.View($('map'),k=>{$('zoomLabel').textContent=Math.round(k*100)+'%';});
let cleanedFiles=null;
const gatewayStorageKey='athar.mw.extraGateways.v1';
let additionalGates=[];
try{
  const saved=JSON.parse(localStorage.getItem(gatewayStorageKey)||'[]');
  if(Array.isArray(saved))additionalGates=[...new Set(saved.filter(value=>typeof value==='string').map(Network.primaryName).filter(Boolean))].filter(gate=>!DefaultGNE.includes(gate));
}catch{}
function prepareDownloads(links,gates){
  cleanedFiles={
    links:[...new Map(links.map(pair=>{const sorted=pair.slice().sort();return [JSON.stringify(sorted),sorted];})).values()],
    gates:[...new Set(gates)]
  };
  $('downloadLinks').disabled=!cleanedFiles.links.length;
  $('downloadGates').disabled=!cleanedFiles.gates.length;
}
function downloadCleaned(kind){
  const values=cleanedFiles?.[kind];if(!values?.length)return;
  const quote=value=>/[",\r\n]/.test(value)?'"'+value.replace(/"/g,'""')+'"':value;
  const header=kind==='links'?'Source NE Name,Sink NE Name':'GNE';
  const lines=kind==='links'?values.map(pair=>pair.map(quote).join(',')):values.map(quote);
  const blob=new Blob(['\uFEFF',header+'\r\n',lines.join('\r\n')+'\r\n'],{type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob),link=document.createElement('a');
  link.href=url;link.download=kind==='links'?'cleaned-links.csv':'cleaned-gne.csv';
  document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
$('downloadLinks').onclick=()=>downloadCleaned('links');
$('downloadGates').onclick=()=>downloadCleaned('gates');
async function readCells(file,kind){
  if(!file)throw Error('Choose a links file first. The GNE file is optional.');
  if(file.size>10*1024*1024)throw Error('Each file must be 10 MB or smaller.');
  if(/\.xlsx$/i.test(file.name)){
    if(!window.ExcelJS)throw Error('The Excel reader could not load. Reload the page or use CSV.');
    const book=new ExcelJS.Workbook();await book.xlsx.load(await file.arrayBuffer());
    const sheet=book.worksheets[0];if(!sheet)throw Error('This Excel file has no worksheets.');
    const headings=new Map();sheet.getRow(1).eachCell(cell=>headings.set(cell.text.trim().toLowerCase().replace(/[\s_-]/g,''),cell.col));
    let columns=null;
    if(kind==='links'&&headings.has('sourcenename')&&headings.has('sinknename'))columns=[headings.get('sourcenename'),headings.get('sinknename'),headings.get('linkname')||headings.get('link')].filter(Boolean);
    else if(kind==='links'&&(headings.has('linkname')||headings.has('link')))columns=[headings.get('linkname')||headings.get('link')];
    else if(kind==='gates')for(const key of ['gnename','gne','gatewayname','gateway'])if(headings.has(key)){columns=[headings.get(key)];break;}
    const cells=[];const add=cell=>cells.push({value:cell.text,location:cell.address,row:cell.row,column:cell.col});
    sheet.eachRow(row=>{if(columns)for(const column of columns)add(row.getCell(column));else row.eachCell(add);});return cells;
  }
  if(!/\.(csv|txt)$/i.test(file.name))throw Error('Use CSV, TXT, or an Excel .xlsx file.');
  // CSV parser supports quoted fields, separators, BOM, and embedded newlines.
  const text=(await file.text()).replace(/^\uFEFF/,'');const cells=[];
  let value='',quoted=false,row=1,col=1;
  const push=()=>{cells.push({value,location:`Row ${row}, column ${col}`,row,column:col});value='';};
  for(let i=0;i<text.length;i++){const c=text[i];
    if(c==='"'){if(quoted&&text[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}
    else if(!quoted&&/[,;\t\n\r]/.test(c)){push();if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row++;col=1;}else col++;}
    else value+=c;
  }
  if(quoted)throw Error('The CSV contains an unclosed quoted field.');push();return cells;
}
function setData(links,gates,ignoredCount=0,message=''){
  const uniqueLinks=[...new Map(links.map(pair=>[pair.slice().sort().join('|'),pair])).values()];
  const uniqueGates=[...new Set(gates)];
  if(!uniqueLinks.length||!uniqueGates.length)throw Error('No valid links and gateways found. Example link: A12S345-C12X3456; gateway: C12X3456.');
  state={adj:Network.graph(uniqueLinks,uniqueGates),links:uniqueLinks,gates:uniqueGates,foundSite:'',affected:new Set()};
  state.assignment=Network.traverse(state.adj,state.gates);
  topologyView.clear();$('extraLinks').checked=true;
  $('impactSite').disabled=false;$('calculateImpact').disabled=false;$('impactResult').value='';$('copyImpact').disabled=true;$('copyLabel').textContent='Copy list';$('impactSummary').textContent='Enter a site name to calculate its impact.';
  $('gneSelect').disabled=false;
  $('search').value='';$('search').disabled=false;$('gneSelect').value='';filterGateways();
  replaceItems($('siteNames'),(function*(){for(const name of [...state.adj.keys()].sort()){const option=document.createElement('option');option.value=name;yield option;}})());
  $('searchStatus').textContent='Enter a full site name to open its gateway map.';
  $('status').textContent='Network imported. Select a gateway or search for any site.'+(ignoredCount?` ${ignoredCount} non-matching cells skipped (including headers).`:'')+(message?' '+message:'');
  draw();
}
// A fragment avoids passing a file-sized array as function arguments.
function replaceItems(container,items){
  const fragment=document.createDocumentFragment();
  for(const item of items)fragment.appendChild(item);
  container.replaceChildren(fragment);
}
function filterGateways(){
  if(!state)return;
  const previous=$('gneSelect').value;
  const matches=state.gates.slice().sort();
  replaceItems($('gneSelect'),(function*(){yield new Option(matches.length?'Select a GNE gateway…':'No matching gateways','');for(const gate of matches)yield new Option(gate,gate);})());
  $('gneSelect').value=matches.includes(previous)?previous:'';
}
function draw(){
  if(!state)return;
  const {adj,gates,links}=state,connected=Network.traverse(adj,gates);
  $('nodesCount').textContent=adj.size;$('gatesCount').textContent=gates.length;$('offlineCount').textContent=adj.size-connected.visited.size;
  const selected=$('gneSelect').value,base=Network.branch(adj,gates,selected);
  $('viewSummary').textContent=selected?`${selected} · ${base.visited.size} assigned sites, including the gateway · Counters cover the whole network.`:'Select a gateway, or find any NE to open its assigned map.';
  const query=state.foundSite||'';
  if(selected){
    const extra=topologyView.render({key:selected,branch:base,links,query,affected:state.affected,onSelectionChange:()=>{state.foundSite='';$('search').value='';$('searchStatus').textContent='Ctrl+click to add or remove sites. Drag a selected site to move the group.';},showExtra:$('extraLinks').checked});
    $('extraCount').textContent=extra;
  }else{
    topologyView.clear();$('extraCount').textContent='0';
    const empty=document.createElement('p');empty.className='empty';empty.textContent=state.foundSite&&!state.assignment.owner.has(state.foundSite)?'This site has no assigned GNE route.':'Select a GNE or search for any site to view its map.';$('map').replaceChildren(empty);
  }
  for(const id of ['zoomIn','zoomOut','fitMap','centerMap','resetLayout','extraLinks'])$(id).disabled=!selected;
  $('fullscreen').disabled=!selected||!document.fullscreenEnabled;

}
$('load').onclick=async()=>{const button=$('load');button.disabled=true;$('status').hidden=true;
  cleanedFiles=null;$('downloadLinks').disabled=true;$('downloadGates').disabled=true;
  try{
  const gatewayFile=$('gates').files[0];
  const [l,g]=await Promise.all([readCells($('links').files[0],'links'),gatewayFile?readCells(gatewayFile,'gates'):Promise.resolve([])]);
  const pl=Network.parseLinks(l),pg=Network.parseGates(g);
  if(!pl.valid.length)throw Error('No valid links found in the selected file.');
  if(gatewayFile&&!pg.valid.length)throw Error('The optional GNE file contains no gateway names. The built-in list is still available.');
  const gates=[...new Set([...DefaultGNE,...additionalGates,...pg.valid.flat()])];
  const added=gates.length-DefaultGNE.length-additionalGates.length;
  const confirmed=Network.applyConnections(pl.valid,gates);
  const ignoredCount=pl.invalid.length+pg.invalid.length;
  const messages=[`Using ${gates.length} GNEs (${DefaultGNE.length} built-in${gates.length>DefaultGNE.length?' + '+(gates.length-DefaultGNE.length)+' added':''}).`];
  if(added)messages.push(`Added ${added} new ${added===1?'gateway':'gateways'} from your GNE file.`);
  if(confirmed.added.length)messages.push('Applied your confirmed A33T001 ↔ A33CA01 connection. It is included in the cleaned links export.');
  setData(confirmed.links,gates,ignoredCount,messages.join(' '));
  prepareDownloads(confirmed.links,gates);
  additionalGates=gates.slice(DefaultGNE.length);
  if(added){try{localStorage.setItem(gatewayStorageKey,JSON.stringify(additionalGates));}catch{$('status').hidden=false;$('status').textContent+=' Browser storage is unavailable; keep the GNE CSV to reload these additions next time.';}}
}catch(e){$('status').hidden=false;$('status').textContent='Import failed: '+e.message;}finally{button.disabled=false;}};
$('search').oninput=findSite;
$('gneSelect').onchange=()=>{clearSiteSearch();draw();if(topologyView.svg)topologyView.focus($('gneSelect').value);$('map').scrollTop=0;$('map').scrollLeft=0;};

$('zoomIn').onclick=()=>topologyView.zoom(1.25);
$('zoomOut').onclick=()=>topologyView.zoom(1/1.25);
$('fitMap').onclick=()=>topologyView.fit();
$('centerMap').onclick=()=>topologyView.center();
$('resetLayout').onclick=()=>{topologyView.clear();draw();};
$('extraLinks').onchange=draw;
$('fullscreen').onclick=async()=>{
  try{if(document.fullscreenElement)await document.exitFullscreen();else await $('mapPanel').requestFullscreen();}
  catch{$('status').textContent='Full screen is unavailable. Maximize the browser window or use the map controls.';}
};
new ResizeObserver(()=>topologyView.reframe()).observe($('map'));
document.addEventListener('fullscreenchange',()=>{$('fullscreenLabel').textContent=document.fullscreenElement?'Exit full screen':'Full screen';});

$('impactSite').oninput=()=>{if(state){state.affected=new Set();draw();}$('impactResult').value='';$('copyImpact').disabled=true;$('copyLabel').textContent='Copy list';$('impactSummary').textContent='Choose Calculate impact to refresh the list.';};
function calculateImpact(){
  $('impactResult').value='';$('copyImpact').disabled=true;$('copyLabel').textContent='Copy list';
  if(state){topologyView.clearSelection();state.affected=new Set();draw();}
  if(!state){$('impactSummary').textContent='Import your links file first.';return;}
  const site=Network.resolveSite($('impactSite').value,state.adj);
  if(!site){$('impactSummary').textContent='Site not found or abbreviation is ambiguous. Use the full name including A, C, or O.';return;}
  const gateway=Network.impactRoot(state.adj,state.gates,site);
  const result=Network.impact(state.adj,state.gates,site);
  state.affected=new Set(result);
  if(gateway){filterGateways();$('gneSelect').value=gateway;state.foundSite=site;$('search').value=site;}
  draw();if(gateway){topologyView.fit(new Set([gateway,...result]));$('searchStatus').textContent=`${site} · ${result.length} impacted · ${gateway}`;}
  $('impactResult').value=result.join(',');$('copyImpact').disabled=!result.length;
  $('impactSummary').textContent=`${site} — Impact: ${result.length} ${result.length===1?'site':'sites'}, including this site. ${gateway?'Assigned GNE: '+gateway:'No GNE route is available to determine dependencies.'}`;
}
$('impactForm').onsubmit=e=>{e.preventDefault();calculateImpact();};

function clearSiteSearch(){
  $('search').value='';if(state)state.foundSite='';
  $('searchStatus').textContent='Enter a full site name to open its gateway map.';
}
function findSite(){
  if(!state)return;
  topologyView.clearSelection();
  const raw=$('search').value.trim(),site=Network.resolveSite(raw,state.adj);
  state.foundSite='';
  if(!raw){$('searchStatus').textContent='Enter a full site name to open its gateway map.';draw();return;}
  if(!site||!state.adj.has(site)){
    $('gneSelect').value='';draw();
    $('searchStatus').textContent='No match yet. Enter a full site name; include A, C, or O if the abbreviation is ambiguous.';return;
  }
  state.foundSite=site;
  const gateway=state.assignment.owner.get(site),hops=state.assignment.depth.get(site);
  if(!gateway){$('gneSelect').value='';draw();$('searchStatus').textContent=site+' has no route to any GNE in this data.';return;}
  filterGateways();$('gneSelect').value=gateway;
  draw();topologyView.focus(site);
  $('searchStatus').textContent=`${site} → ${gateway} · ${hops} ${hops===1?'hop':'hops'}`;
}
for(const id of ['links','gates'])$(id).addEventListener('change',()=>{
  $(id+'Name').textContent=$(id).files[0]?.name||(id==='links'?'Choose a link or MLR file':'Optional — add new gateways');
});
$('copyImpact').onclick=async()=>{
  const value=$('impactResult').value;if(!value)return;
  try{
    if(!navigator.clipboard?.writeText)throw Error('Clipboard unavailable');
    await navigator.clipboard.writeText(value);$('copyLabel').textContent='Copied';
  }catch{
    $('impactResult').focus();$('impactResult').select();
    let copied=false;try{copied=document.execCommand?.('copy')===true;}catch{}
    $('copyLabel').textContent=copied?'Copied':'Selected — press Ctrl+C';
  }
};
